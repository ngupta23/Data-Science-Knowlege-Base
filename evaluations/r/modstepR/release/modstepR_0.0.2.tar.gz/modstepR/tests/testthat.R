library(testthat)
library(modstepR)

test_check("modstepR")
